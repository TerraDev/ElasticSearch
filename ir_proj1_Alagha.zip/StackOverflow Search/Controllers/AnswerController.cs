﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Nest;
using StackOverflow_Search.Models;

namespace StackOverflow_Search.Controllers
{
    [Route("api/Answer")]
    [ApiController]
    public class AnswerController : ControllerBase
    {
        private readonly IElasticClient _elasticClient;

        public AnswerController(IElasticClient elasticClient)
        {
            _elasticClient = elasticClient;
        }

        [HttpGet("SearchAnsbyWord")]
        public IActionResult Search(string Keyword)
        {
            var searchResponse = _elasticClient.Search<Answer>(s => s
            .Size(200)
            .Query(q => q.Match(m => m
            .Field(f => f.Body)
            .Query(Keyword)))
            .Index("answers"));

            return Ok(searchResponse.Documents);
        }

        [HttpGet("SearchAnsbyQIdnScore")]
        public IActionResult Search(int QId, int Score)
        {
            var searchResponse = _elasticClient.Search<Answer>(s => s
            .Size(200)
            .Query(q => q.Range(c => c
            .Field(
                x=>x.Score)
                .GreaterThan(Score))
                &&  +q.Term(p => p.ParentId, QId)
             ).Index("answers"));

            return Ok(searchResponse.Documents);
        }

        [HttpGet("SearchAnsbyWordnDate")]
        public IActionResult Search(string Keyword, DateTime StartDate, DateTime EndDate)
        {
            var searchResponse = _elasticClient.Search<Answer>(s => s
            .Size(200)
            .Query(q => q.DateRange(c => c.Field(
                x => x.CreationDate)
            .GreaterThan(StartDate)
            .LessThan(EndDate)) &&
            +q.Match(c => c.Field(f => f.Body).Query(Keyword)
            )).Index("answers"));

            return Ok(searchResponse.Documents);
        }
    }
}

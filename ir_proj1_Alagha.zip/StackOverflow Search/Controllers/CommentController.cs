﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Nest;
using StackOverflow_Search.Models;

namespace StackOverflow_Search.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CommentController : ControllerBase
    {
        private readonly IElasticClient _elasticClient;

        public CommentController(IElasticClient elasticClient)
        {
            _elasticClient = elasticClient;
        }

        [HttpGet("GetComplexComment")]
        public IActionResult GetComment()
        {
            var searchResponse = _elasticClient.Search<Post>(s => s
            .Size(100)
            .Query(q => q
            .MatchAll()
             )
            .Index("posts"));

            List<int> ids = new List<int>();
            foreach (Post x in searchResponse.Documents)
            {
                var post1 = _elasticClient.Search<Comment>(s => s
                .Size(500)
                .Query(q => q
                .Term(p => p.PostId, x.Id) && q
                .TermsSet(c => c
                    .Field(p => p.Text)
                    .Terms(x.Tags)
                ))
                .Index("comments")).Documents;

                if (post1.Count != 0)
                {
                    ids.Add(post1.First().PostId);
                }
            }

            var finposts = searchResponse.Documents.Where(x => ids.Contains(x.Id));
            return Ok(finposts);
        }
    }
}

﻿using Nest;
using StackOverflow_Search.Models;

namespace StackOverflow_Search.Extensions
{
    public static class ElasticSearchExtension
    {
        public static void AddElasticsearch(
        this IServiceCollection services, IConfiguration configuration)
        {
            var url = configuration["ELKConfiguration:Uri"];
            var defaultIndex = configuration["ELKConfiguration:Indexes:QuestionIndex"];
            var Index2 = configuration["ELKConfiguration:Indexes:AnswerIndex"];
            var Index3 = configuration["ELKConfiguration:Indexes:CommentIndex"];

            var settings = new ConnectionSettings(new Uri(url))//.BasicAuthentication(userName, pass)
                .PrettyJson();

            AddDefaultMappings(settings);

            var client = new ElasticClient(settings);

            services.AddSingleton<IElasticClient>(client);

            CreateIndex(client, defaultIndex, Index2, Index3);
        }

        private static void AddDefaultMappings(ConnectionSettings settings)
        {
            settings.DefaultMappingFor<Post>(m => m);
            settings.DefaultMappingFor<Answer>(m => m);
            settings.DefaultMappingFor<Comment>(m => m);
        }

        private static void CreateIndex(IElasticClient client, string indexName, string index2, string index3)
        {
            var createIndexResponse = client.Indices.Create(indexName,
                index => index.Map<Post>(x => x.AutoMap())
            );

            client.Indices.Create(
                index2,
                index => index.Map<Answer>(x => x.AutoMap())
            );

            client.Indices.Create(
                index3,
                index => index.Map<Comment>(x => x.AutoMap())
            );
        }
    }
}

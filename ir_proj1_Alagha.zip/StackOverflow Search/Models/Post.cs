﻿namespace StackOverflow_Search.Models
{
    public class Post
    {
        public Post()
        {

        }

        public Post(PostTmp post2)
        {
            Id = post2.Id;
            PostTypeId = post2.PostTypeId;
            AcceptedAnswerId = post2.AcceptedAnswerId;
            ParentId = post2.ParentId;
            CreationDate = post2.CreationDate;
            DeletionDate = post2.DeletionDate;
            Score = post2.Score;
            ViewCount = post2.ViewCount;
            Body = post2.Body;
            OwnerUserId = post2.OwnerUserId;
            OwnerDisplayName = post2.OwnerDisplayName;
            LastEditorUserId = post2.LastEditorUserId;
            LastEditorDisplayName = post2.LastEditorDisplayName;
            LastEditDate = post2.LastEditDate;
            LastActivityDate = post2.LastActivityDate;
            Title = post2.Title;
            Tags = post2.Tags?.Split(new char[] { '>', '<' }, StringSplitOptions.RemoveEmptyEntries).ToList(); ;
            AnswerCount = post2.AnswerCount;
            CommentCount = post2.CommentCount;
            FavoriteCount = post2.FavoriteCount;
            ClosedDate = post2.ClosedDate;
            CommunityOwnedDate = post2.CommunityOwnedDate;
            ContentLicense = post2.ContentLicense;
        }

        public int Id { get; set; }
        public short PostTypeId { get; set; }
        public int? AcceptedAnswerId { get; set; }
        public int? ParentId { get; set; }
        public DateTime CreationDate { get; set; }
        public DateTime? DeletionDate { get; set; }
        public int Score { get; set; }
        public int ViewCount { get; set; }
        public string? Body { get; set; }
        public int OwnerUserId { get; set; }
        public string? OwnerDisplayName { get; set; }
        public int? LastEditorUserId { get; set; }
        public string? LastEditorDisplayName { get; set; }
        public DateTime? LastEditDate { get; set; }
        public DateTime LastActivityDate { get; set; }
        public string Title { get; set; } = "";
        public List<string>? Tags { get; set; }
        public int? AnswerCount { get; set; }
        public int CommentCount { get; set; }
        public int? FavoriteCount { get; set; }
        public DateTime? ClosedDate { get; set; }
        public DateTime? CommunityOwnedDate { get; set; }
        public string? ContentLicense { get; set; }
    }
}
